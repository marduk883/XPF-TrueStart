const isMac = navigator.userAgent.toUpperCase().indexOf('MAC') >= 0;
const modKeyName = isMac ? 'Cmd' : 'Ctrl';

document.addEventListener('DOMContentLoaded', () => {
    loadFavorites();
    loadNote();
    loadNotePosition();
    makeDraggable();
    loadMusicWidget();
    makeMainWindowDraggable();

    applyTheme(getCurrentTheme());

    const changeThemeBtn = document.getElementById('changeThemeBtn');
    if (changeThemeBtn) {
        changeThemeBtn.onclick = function() {
            let current = getCurrentTheme();
            let next = (current + 1) % 7; // 7 tema oldu
            setCurrentTheme(next);
            applyTheme(next);
        };
    }

    


const searchInput = document.getElementById('asmd21q');

if (searchInput) {
    let suggestBox = document.createElement('div');
    suggestBox.id = 'googleSuggestBox';
    suggestBox.style.position = 'absolute';
    suggestBox.style.zIndex = '9999';
    suggestBox.style.display = 'none';
    suggestBox.style.maxHeight = '180px';
    suggestBox.style.overflowY = 'auto';
    document.body.appendChild(suggestBox);

    function positionSuggestBox() {
        const rect = searchInput.getBoundingClientRect();
        suggestBox.style.left = rect.left + window.scrollX + 'px';
        suggestBox.style.top = rect.bottom + window.scrollY + 'px';
        suggestBox.style.width = rect.width + 'px';
    }

    function showSuggestions(suggestions) {
        if (suggestions.length === 0) {
            suggestBox.style.display = 'none';
            return;
        }
        
        suggestBox.innerHTML = '';
        suggestions.forEach(s => {
            const item = document.createElement('div');
            item.textContent = s;
            item.style.padding = '8px 12px';
            item.style.cursor = 'pointer';
            item.style.transition = 'all 0.15s ease';
            
            item.addEventListener('mousedown', function (e) {
                e.preventDefault();
                searchInput.value = s;
                suggestBox.style.display = 'none';
            });
            
            suggestBox.appendChild(item);
        });
        suggestBox.style.display = 'block';
    }

    searchInput.addEventListener('input', async function () {
        const query = this.value.trim();
        if (!query) {
            suggestBox.style.display = 'none';
            return;
        }
        
        positionSuggestBox();
        
        try {
            const res = await fetch(`https://suggestqueries.google.com/complete/search?client=firefox&q=${encodeURIComponent(query)}`);
            const data = await res.json();
            const suggestions = data[1].slice(0, 5);
            showSuggestions(suggestions);
        } catch (e) {
            suggestBox.style.display = 'none';
        }
    });

    searchInput.addEventListener('blur', function () {
        setTimeout(() => { suggestBox.style.display = 'none'; }, 150);
    });

    window.addEventListener('resize', positionSuggestBox);
    searchInput.addEventListener('focus', positionSuggestBox);
}

function getCurrentTheme() {
    return parseInt(localStorage.getItem('themeIndex') || '0', 10);
}

function setCurrentTheme(idx) {
    localStorage.setItem('themeIndex', String(idx));
}

function applyTheme(idx) {
    document.body.classList.remove('theme-retro', 'theme-retro-dark', 'theme-retro-dark2', 'theme-modern-light', 'theme-modern-dark', 'theme-neon-dark', 'theme-glass-dark');
    switch(idx) {
        case 0:
            document.body.classList.add('theme-retro');
            break;
        case 1:
            document.body.classList.add('theme-retro-dark');
            break;
        case 2:
            document.body.classList.add('theme-retro-dark2');
            break;
        case 3:
            document.body.classList.add('theme-modern-light');
            break;
        case 4:
            document.body.classList.add('theme-modern-dark');
            break;
        case 5:
            document.body.classList.add('theme-neon-dark');
            break;
        case 6:
            document.body.classList.add('theme-glass-dark');
            break;
    }
}

    document.getElementById('addFavBtn').addEventListener('click', addFavorite);

    document.getElementById('newSiteUrl').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            addFavorite();
        }
    });

    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key.toLowerCase() === 'z') {
            function numListener(ev) {
                if (/^[1-9]$/.test(ev.key)) {
                    ev.preventDefault();
                    const keyNum = parseInt(ev.key);
                    const favs = JSON.parse(localStorage.getItem('myRetroFavs'));
                    if (favs && favs.length >= keyNum) {
                        const site = favs[keyNum - 1];
                        window.open(site.url, '_blank');
                    }
                }
                document.removeEventListener('keydown', numListener);
            }
            document.addEventListener('keydown', numListener);
        }
    });

    document.getElementById('favGrid').addEventListener('click', function(e) {
        if (e.target.classList.contains('delete-btn')) {
            const idx = parseInt(e.target.dataset.index, 10);
            deleteFavorite(idx);
        }
    });

    const editBtn = document.getElementById('editGridBtn');
    const popup = document.getElementById('editGridPopup');
    const closeBtn = document.getElementById('closeGridPopupBtn');
    const saveBtn = document.getElementById('saveGridRowsBtn');
    const rowsSelect = document.getElementById('favGridRows');

    editBtn.addEventListener('click', () => {
        rowsSelect.value = getGridRows();
        popup.style.display = 'block';
    });

    closeBtn.addEventListener('click', () => {
        popup.style.display = 'none';
    });

    saveBtn.addEventListener('click', () => {
        setGridRows(rowsSelect.value);
        popup.style.display = 'none';
    });

    const bgInput = document.getElementById('bgImageInput');
    const uploadBtn = document.getElementById('bgImageUploadBtn');
    const removeBtn = document.getElementById('bgImageRemoveBtn');

    function applyBgImage() {
        const imgData = localStorage.getItem('customBgImage');
        if (imgData) {
            document.body.style.backgroundImage = `url('${imgData}')`;
            document.body.style.backgroundSize = 'cover';
            document.body.style.backgroundPosition = 'center';
            removeBtn.style.display = '';
        } else {
            document.body.style.backgroundImage = 'radial-gradient(circle, #538ae2 0%, #3b6bcc 100%)';
            document.body.style.backgroundColor = '#008080';
            document.body.style.backgroundSize = '';
            document.body.style.backgroundPosition = '';
            removeBtn.style.display = 'none';
        }
    }
    applyBgImage();

    if (uploadBtn) {
        uploadBtn.onclick = () => bgInput.click();
    }
    if (bgInput) {
        bgInput.onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = function(ev) {
                localStorage.setItem('customBgImage', ev.target.result);
                applyBgImage();
            };
            reader.readAsDataURL(file);
        };
    }
    if (removeBtn) {
        removeBtn.onclick = () => {
            localStorage.removeItem('customBgImage');
            bgInput.value = '';
            applyBgImage();
        };
    }

    document.getElementById('stickyNoteCloseBtn').addEventListener('click', function() {
        const note = document.getElementById('stickyNote');
        const btn = document.getElementById('showNoteBtn');
        const bgWidget = document.getElementById('bgImageWidget');
        if (note.style.display !== 'none') {
            note.style.display = 'none';
            btn.style.display = 'none';
            let restoreNoteBtn = document.getElementById('restoreStickyNoteBtn');
            if (!restoreNoteBtn) {
                restoreNoteBtn = document.createElement('button');
                restoreNoteBtn.id = 'restoreStickyNoteBtn';
                restoreNoteBtn.textContent = 'Show Note';
                restoreNoteBtn.style.padding = '2px 8px';
                restoreNoteBtn.style.marginLeft = '4px';
                restoreNoteBtn.style.background = '#ECE9D8';
                restoreNoteBtn.style.border = '1px solid #0055EA';
                restoreNoteBtn.style.borderRadius = '6px';
                restoreNoteBtn.style.fontSize = '13px';
                restoreNoteBtn.style.cursor = 'pointer';
                bgWidget.appendChild(restoreNoteBtn);

                restoreNoteBtn.onclick = function() {
                    note.style.display = 'flex';
                    restoreNoteBtn.remove();
                };
            }
        }
    });
    document.getElementById('showNoteBtn').addEventListener('click', toggleStickyNote);

    const bgWidget = document.getElementById('bgImageWidget');
    const resetBtn = document.createElement('button');
    resetBtn.id = 'resetPositionsBtn';
    resetBtn.textContent = 'Reset Positions';
    resetBtn.style.padding = '2px 8px';
    resetBtn.style.marginLeft = '4px';
    bgWidget.appendChild(resetBtn);

    const resetPopup = document.createElement('div');
    resetPopup.id = 'resetPositionsPopup';
    resetPopup.style.display = 'none';
    resetPopup.style.position = 'fixed';
    resetPopup.style.left = '50%';
    resetPopup.style.top = '50%';
    resetPopup.style.transform = 'translate(-50%,-50%)';
    resetPopup.style.background = '#ECE9D8';
    resetPopup.style.border = '3px solid #0055EA';
    resetPopup.style.borderRadius = '8px';
    resetPopup.style.boxShadow = '4px 4px 10px rgba(0,0,0,0.5)';
    resetPopup.style.zIndex = '1000';
    resetPopup.style.padding = '24px';
    resetPopup.style.minWidth = '320px';
    resetPopup.innerHTML = `
        <div style="font-weight:bold; font-size:15px; margin-bottom:8px; color:#0058EE;">
            🛠️ Reset Positions
        </div>
        <div style="font-size:12px; margin-bottom:12px;">
            You can reset the positions of your favorites and widgets.<br>
            Choose what you want to reset:
        </div>
        <button id="resetFavsBtn" style="padding:6px 18px; font-size:13px; background:#0058EE; color:white; border:none; border-radius:4px; cursor:pointer; margin-bottom:10px; width:100%;">Reset Favorites Locations</button>
        <button id="resetWidgetsBtn" style="padding:6px 18px; font-size:13px; background:#34A853; color:white; border:none; border-radius:4px; cursor:pointer; margin-bottom:10px; width:100%;">Reset Widget Locations</button>
        <button id="resetAllBtn" style="padding:6px 18px; font-size:13px; background:#EA4335; color:white; border:none; border-radius:4px; cursor:pointer; margin-bottom:10px; width:100%;">Reset All</button>
        <div style="margin-top:18px; text-align:right;">
            <button id="closeResetPopupBtn" style="padding:4px 14px; font-size:13px; background:#ECE9D8; color:#0058EE; border:1px solid #0058EE; border-radius:4px; cursor:pointer;">Cancel</button>
        </div>
    `;
    document.body.appendChild(resetPopup);

    resetBtn.onclick = () => {
        resetPopup.style.display = 'block';
    };
    document.getElementById('closeResetPopupBtn').onclick = () => {
        resetPopup.style.display = 'none';
    };

    document.getElementById('resetFavsBtn').onclick = () => {
        let outsideFavs = JSON.parse(localStorage.getItem('outsideFavs')) || [];
        if (outsideFavs.length > 0) {
            let favs = JSON.parse(localStorage.getItem('myRetroFavs')) || [];
            favs = favs.concat(outsideFavs.map(fav => ({ name: fav.name, url: fav.url })));
            localStorage.setItem('myRetroFavs', JSON.stringify(favs));
        }
        localStorage.removeItem('outsideFavs');
        loadFavorites();
        resetPopup.style.display = 'none';
    };

    document.getElementById('resetWidgetsBtn').onclick = () => {
        localStorage.removeItem('mainWindowPosition');
        localStorage.removeItem('notePosition');
        const win = document.querySelector('.window');
        win.style.transform = '';
        const note = document.getElementById('stickyNote');
        note.style.transform = '';
        resetPopup.style.display = 'none';
    };

    document.getElementById('resetAllBtn').onclick = () => {
        let outsideFavs = JSON.parse(localStorage.getItem('outsideFavs')) || [];
        if (outsideFavs.length > 0) {
            let favs = JSON.parse(localStorage.getItem('myRetroFavs')) || [];
            favs = favs.concat(outsideFavs.map(fav => ({ name: fav.name, url: fav.url })));
            localStorage.setItem('myRetroFavs', JSON.stringify(favs));
        }
        localStorage.removeItem('outsideFavs');
        localStorage.removeItem('mainWindowPosition');
        localStorage.removeItem('notePosition');
        loadFavorites();
        const win = document.querySelector('.window');
        win.style.transform = '';
        const note = document.getElementById('stickyNote');
        note.style.transform = '';
        resetPopup.style.display = 'none';
    };
    document.querySelector('.minimize-btn').addEventListener('click', function() {
    const win = document.querySelector('.window');
    if (win.style.display !== 'none') {
        win.style.display = 'none';
        let restoreBtn = document.getElementById('restoreMainWindowBtn');
        if (!restoreBtn) {
            restoreBtn = document.createElement('button');
            restoreBtn.id = 'restoreMainWindowBtn';
            restoreBtn.textContent = 'Show Main Window';
            restoreBtn.style.padding = '2px 8px';
            restoreBtn.style.marginLeft = '4px';
            restoreBtn.style.background = '#ECE9D8';
            restoreBtn.style.border = '1px solid #0055EA';
            restoreBtn.style.borderRadius = '6px';
            restoreBtn.style.fontSize = '13px';
            restoreBtn.style.cursor = 'pointer';

            const bgWidget = document.getElementById('bgImageWidget');
            bgWidget.appendChild(restoreBtn);

            restoreBtn.onclick = function() {
                win.style.display = '';
                restoreBtn.remove();
            };
        }
    }
});
    
});

const defaultFavs = [
    { name: "Gmail", url: "https://mail.google.com/" },
    { name: "Gemini", url: "https://gemini.google.com/app?hl=tr" },
    { name: "YouTube", url: "https://www.youtube.com/" },
    { name: "Chatgpt", url: "https://chatgpt.com/" }
];

function getGridRows() {
    return parseInt(localStorage.getItem('favGridRows') || "1", 10);
}

function setGridRows(rows) {
    localStorage.setItem('favGridRows', String(rows));
    loadFavorites();
}

let dragSrcEl = null;

function handleDragStart(e) {
    dragSrcEl = this;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/html', this.innerHTML);
    this.classList.add('dragging');
}

function handleDragOver(e) {
    if (e.preventDefault) {
        e.preventDefault();
    }
    e.dataTransfer.dropEffect = 'move';
    return false;
}

function handleDrop(e) {
    if (e.stopPropagation) {
        e.stopPropagation();
    }

    if (dragSrcEl !== this) {
        const srcIndex = parseInt(dragSrcEl.dataset.index);
        const targetIndex = parseInt(this.dataset.index);

        let favs = JSON.parse(localStorage.getItem('myRetroFavs'));
        
        const itemToMove = favs[srcIndex];
        favs.splice(srcIndex, 1);
        favs.splice(targetIndex, 0, itemToMove);
        
        localStorage.setItem('myRetroFavs', JSON.stringify(favs));
        loadFavorites();
    }

    return false;
}

function handleDragEnd(e) {
    this.classList.remove('dragging');
    const items = document.querySelectorAll('.fav-item');
    items.forEach(function (item) {
        item.classList.remove('dragging');
    });
}

function loadFavorites() {
    const container = document.getElementById('favGrid');
    container.innerHTML = "";

    let favs = JSON.parse(localStorage.getItem('myRetroFavs'));
    if (!favs) {
        favs = defaultFavs;
        localStorage.setItem('myRetroFavs', JSON.stringify(favs));
    }

    const total = favs.length;
    let userSelectedRows = getGridRows(); 

    const itemsPerView = 4; 

    let neededRows = Math.ceil(total / itemsPerView);
    if (neededRows < 1) neededRows = 1;

    const rows = Math.min(userSelectedRows, neededRows);

    const columns = Math.max(4, Math.ceil(total / rows));

    const inner = document.createElement('div');
    inner.className = 'fav-inner';
    inner.style.display = 'grid';
    inner.style.gridTemplateRows = `repeat(${rows}, 1fr)`;
    
    inner.style.gridTemplateColumns = `repeat(${columns}, minmax(130px, 1fr))`;
    
    inner.style.width = '100%';
    inner.style.height = '100%';
    inner.style.boxSizing = 'border-box';

    if (total === 0) {
        container.style.height = '40px';
    } else {
        const rowHeight = 95;
        container.style.height = (rows * rowHeight + 24) + 'px';
    }

    for (let i = 0; i < rows * columns; i++) {
        const item = document.createElement('div');
        item.className = 'fav-item';

        if (i < favs.length) {
            item.setAttribute('draggable', 'true');
            item.dataset.index = i;
            item.addEventListener('dragstart', handleDragStart, false);
            item.addEventListener('dragover', handleDragOver, false);
            item.addEventListener('drop', handleDrop, false);
            item.addEventListener('dragend', handleDragEnd, false);

            const site = favs[i];
            const iconDiv = document.createElement('div');
            iconDiv.className = 'pixel-icon';
            iconDiv.style.background = 'transparent';
            iconDiv.style.border = 'none'; // Çerçeve yok
            iconDiv.style.width = '32px';
            iconDiv.style.height = '32px';
            iconDiv.style.marginBottom = '5px';

            let customIcons = JSON.parse(localStorage.getItem('customFavIcons') || '{}');
            if (customIcons[site.url]) {
                iconDiv.innerHTML = `<img src="${customIcons[site.url]}" style="width:100%;height:100%;object-fit:contain;">`;
            } else {
                const faviconUrl = `https://icons.duckduckgo.com/ip3/${new URL(site.url).hostname}.ico`;
                const img = document.createElement('img');
                img.src = faviconUrl;
                img.style.width = '100%';
                img.style.height = '100%';
                img.style.objectFit = 'contain';
                img.onerror = function() {
                    iconDiv.textContent = site.name.charAt(0).toUpperCase();
                    iconDiv.style.backgroundColor = '#ADD8E6';
                };
                img.onload = function() {
                    iconDiv.innerHTML = '';
                    iconDiv.appendChild(img);
                };
                iconDiv.textContent = site.name.charAt(0).toUpperCase();
                iconDiv.style.backgroundColor = '#ADD8E6';
                iconDiv.appendChild(img);
            }

            item.addEventListener('contextmenu', function(e) {
                e.preventDefault();
                const fileInput = document.createElement('input');
                fileInput.type = 'file';
                fileInput.accept = 'image/*';
                fileInput.style.display = 'none';
                document.body.appendChild(fileInput);
                fileInput.onchange = function(ev) {
                    const file = ev.target.files[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = function(event) {
                        customIcons[site.url] = event.target.result;
                        localStorage.setItem('customFavIcons', JSON.stringify(customIcons));
                        loadFavorites();
                    };
                    reader.readAsDataURL(file);
                };
                fileInput.click();
                setTimeout(() => fileInput.remove(), 1000);
            });

            const nameSpan = document.createElement('span');
            nameSpan.className = 'fav-name';
            nameSpan.textContent = site.name; 
            
            item.appendChild(iconDiv);
            item.appendChild(nameSpan);

            if (i < 9) {
                const shortcutSpan = document.createElement('span');
                shortcutSpan.className = 'fav-shortcut';
                shortcutSpan.textContent = `${modKeyName}+Z+${i+1}`;
                item.appendChild(shortcutSpan);
            }

            const deleteButton = document.createElement('button');
            deleteButton.className = 'delete-btn';
            deleteButton.dataset.index = i;
            deleteButton.setAttribute('aria-label', 'Delete favorite');
            deleteButton.textContent = '×'; 

            item.appendChild(deleteButton);

            item.addEventListener('click', function(e) {
                if(!e.target.classList.contains('delete-btn')) {
                   window.open(site.url, '_blank');
                }
            });

        } else {
            item.style.background = "transparent";
            item.style.boxShadow = "none";
            item.style.border = "none";
            item.addEventListener('mouseenter', function() {
                item.style.border = '1px dashed #538ae2';
            });
            item.addEventListener('mouseleave', function() {
                item.style.border = 'none';
            });
        }
        inner.appendChild(item);
    }

    container.appendChild(inner);
    enableOutsideDrag();
    renderOutsideFavs(); 
}

function addFavorite() {
    const nameInput = document.getElementById('newSiteName');
    const urlInput = document.getElementById('newSiteUrl');
    
    let name = nameInput.value.trim();
    let url = urlInput.value.trim();

    if (!name || !url) {
        alert("Please enter both name and URL!");
        return;
    }

    if (!/^https?:\/\//i.test(url)) {
        url = 'https://' + url;
    }

    let favs = JSON.parse(localStorage.getItem('myRetroFavs')) || [];
    favs.push({ name: name, url: url });
    localStorage.setItem('myRetroFavs', JSON.stringify(favs));

    nameInput.value = "";
    urlInput.value = "";
    loadFavorites();
}

function deleteFavorite(index) {
    let favs = JSON.parse(localStorage.getItem('myRetroFavs'));
    favs.splice(index, 1);
    localStorage.setItem('myRetroFavs', JSON.stringify(favs));
    loadFavorites();
}

function toggleStickyNote() {
    const note = document.getElementById('stickyNote');
    const btn = document.getElementById('showNoteBtn');
    
    if (note.style.display === 'none') {
        note.style.display = 'flex';
        btn.style.display = 'none';
    } else {
        note.style.display = 'none';
        btn.style.display = 'block';
    }
}

function loadNote() {
    const savedNote = localStorage.getItem('stickyNote');
    if (savedNote) {
        document.getElementById('noteText').value = savedNote;
    }
}

document.getElementById('noteText').addEventListener('input', function() {
    localStorage.setItem('stickyNote', this.value);
});

function makeDraggable() {
    const note = document.getElementById('stickyNote');
    let isDragging = false;
    let currentX;
    let currentY;
    let initialX;
    let initialY;
    let xOffset = 0;
    let yOffset = 0;

    const header = note.querySelector('.sticky-note-header');

    header.addEventListener('mousedown', dragStart);
    document.addEventListener('mousemove', drag);
    document.addEventListener('mouseup', dragEnd);

    function dragStart(e) {
        if (e.target.classList.contains('sticky-note-close')) return;
        initialX = e.clientX - xOffset;
        initialY = e.clientY - yOffset;
        isDragging = true;
    }

    function drag(e) {
        if (isDragging) {
            e.preventDefault();
            currentX = e.clientX - initialX;
            currentY = e.clientY - initialY;
            xOffset = currentX;
            yOffset = currentY;
            setTranslate(currentX, currentY, note);
        }
    }

    function dragEnd(e) {
        if (isDragging) {
            setTranslate(currentX, currentY, note);
            saveNotePosition(currentX, currentY);
            xOffset = currentX;
            yOffset = currentY;
            isDragging = false;
        }
    }

    function setTranslate(xPos, yPos, el) {
        el.style.transform = `translate3d(${xPos}px, ${yPos}px, 0)`;
    }
}

function saveNotePosition(x, y) {
    localStorage.setItem('notePosition', JSON.stringify({ x, y }));
}

function loadNotePosition() {
    const savedPosition = localStorage.getItem('notePosition');
    if (savedPosition) {
        const { x, y } = JSON.parse(savedPosition);
        const note = document.getElementById('stickyNote');
        note.style.transform = `translate3d(${x}px, ${y}px, 0)`;
    }
}


let currentPlayingVideoId = null;

function updateVideoAmbient(videoId) {
    const ambientBg = document.getElementById('videoAmbientBg');
    const ambientImg = document.getElementById('videoAmbientImg');
    
    if (videoId) {
        const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
        
        ambientImg.onerror = function() {
            ambientImg.src = `https://img.youtube.com/vi/${videoId}/sddefault.jpg`;
        };
        
        ambientImg.src = thumbnailUrl;
        ambientBg.classList.add('active');
    } else {
        ambientBg.classList.remove('active');
    }
}

async function loadMusicWidget() {
    const select = document.getElementById('musicCategory');
    const playBtn = document.getElementById('playMusicBtn');
    const stopBtn = document.getElementById('stopMusicBtn');
    const likeBtn = document.getElementById('likeMusicBtn'); 
    const playerWrap = document.getElementById('musicPlayer');
    const ytFrame = document.getElementById('ytPlayer');

    let data = {};
    try {
        const res = await fetch('video_ids.json', { cache: 'no-store' });
        data = await res.json();
    } catch (err) {
        console.log("video_ids.json could not be loaded", err);
        return;
    }


    const randomOpt = document.createElement('option');
    randomOpt.value = "__random__";
    randomOpt.textContent = "Random Mix";
    select.appendChild(randomOpt);

    Object.keys(data).forEach(cat => {
        const opt = document.createElement('option');
        opt.value = cat;
        opt.textContent = cat;
        select.appendChild(opt);
    });

    const userFavOpt = document.createElement('option');
    userFavOpt.value = "__userfavs__";
    userFavOpt.textContent = "♥ My Favorites";
    userFavOpt.style.color = "blue"; 
    select.appendChild(userFavOpt);


    playBtn.onclick = () => {
        let selectedCat = select.value;
        let videoId = null;

        if (selectedCat === "__userfavs__") {
            const myFavs = JSON.parse(localStorage.getItem('myMusicFavs')) || [];
            if (myFavs.length === 0) {
                alert("You haven't liked any songs yet! Play other categories and click '👍' to add them here.");
                return;
            }
            videoId = myFavs[Math.floor(Math.random() * myFavs.length)];
        } 
        else if (selectedCat === "__random__") {
            const allIds = Object.values(data).flat();
            if (allIds.length > 0) {
                videoId = allIds[Math.floor(Math.random() * allIds.length)];
            }
        } 
        else {
            const ids = data[selectedCat];
            if (ids && ids.length > 0) {
                videoId = ids[Math.floor(Math.random() * ids.length)];
            }
        }

        if (videoId) {
            currentPlayingVideoId = videoId; 
            ytFrame.src = `https://marduk883.github.io/youtube_embed/?v=${videoId}`;
            playerWrap.style.display = 'block';
            
            likeBtn.style.display = 'inline-block';
            
            updateVideoAmbient(videoId);
        } else {
            alert("No video found!");
        }
    };

    stopBtn.onclick = () => {
        ytFrame.src = "";
        playerWrap.style.display = 'none';
        currentPlayingVideoId = null;
        
        likeBtn.style.display = 'none';
        
        updateVideoAmbient(null);
    };

    likeBtn.onclick = () => {
        if (!currentPlayingVideoId) return;

        let myFavs = JSON.parse(localStorage.getItem('myMusicFavs')) || [];

        if (!myFavs.includes(currentPlayingVideoId)) {
            myFavs.push(currentPlayingVideoId);
            localStorage.setItem('myMusicFavs', JSON.stringify(myFavs));
            alert("Song added to your '♥ My Favorites' list!");
        } else {
            alert("This song is already in your favorites!");
        }
    };
}

function makeMainWindowDraggable() {
    const win = document.querySelector('.window');
    const header = win.querySelector('.title-bar');
    let isDragging = false, startX = 0, startY = 0, offsetX = 0, offsetY = 0;

    const savedPos = localStorage.getItem('mainWindowPosition');
    if (savedPos) {
        const { x, y } = JSON.parse(savedPos);
        win.style.transform = `translate(${x}px, ${y}px)`;
        offsetX = x;
        offsetY = y;
    }

    header.style.cursor = 'move';

    header.addEventListener('mousedown', function(e) {
        isDragging = true;
        startX = e.clientX - offsetX;
        startY = e.clientY - offsetY;
        document.body.style.userSelect = 'none';
    });

    document.addEventListener('mousemove', function(e) {
        if (!isDragging) return;
        offsetX = e.clientX - startX;
        offsetY = e.clientY - startY;
        win.style.transform = `translate(${offsetX}px, ${offsetY}px)`;
    });

    document.addEventListener('mouseup', function() {
        if (isDragging) {
            win.style.transform = `translate(${offsetX}px, ${offsetY}px)`;
            localStorage.setItem('mainWindowPosition', JSON.stringify({ x: offsetX, y: offsetY }));
        }
        isDragging = false;
        document.body.style.userSelect = '';
    });
}

function createOutsideShortcut(site, x, y, idx) {
    const GRID_SIZE = 80;
    function snapToGrid(coord, max) {
        let snapped = Math.round(coord / GRID_SIZE) * GRID_SIZE;
        if (snapped < 0) snapped = 0;
        if (snapped > max) snapped = max;
        return snapped;
    }

    const shortcut = document.createElement('div');
    shortcut.className = 'fav-item outside-fav';
    shortcut.style.position = 'fixed';

    shortcut.style.background = 'transparent';
    shortcut.style.boxShadow = 'none';
    shortcut.style.border = 'none'; 
    shortcut.style.borderRadius = '8px';
    shortcut.style.cursor = 'grab';
    shortcut.style.width = '40px';
    shortcut.style.height = '40px';
    shortcut.style.display = 'flex';
    shortcut.style.flexDirection = 'column';
    shortcut.style.alignItems = 'center';
    shortcut.style.justifyContent = 'center';

    const maxLeft = window.innerWidth - GRID_SIZE;
    const maxTop = window.innerHeight - GRID_SIZE;

    shortcut.style.left = snapToGrid(x, maxLeft) + 'px';
    shortcut.style.top = snapToGrid(y, maxTop) + 'px';
    shortcut.style.zIndex = 9999;

    shortcut.setAttribute('draggable', 'true');
    shortcut.dataset.index = idx;

    let customIcons = JSON.parse(localStorage.getItem('customFavIcons') || '{}');
    const iconDiv = document.createElement('div');
    iconDiv.className = 'pixel-icon';
    iconDiv.style.background = 'transparent';
    iconDiv.style.border = 'none';
    iconDiv.style.width = '32px';
    iconDiv.style.height = '32px';
    iconDiv.style.marginBottom = '0';

    if (customIcons[site.url]) {
        iconDiv.innerHTML = `<img src="${customIcons[site.url]}" style="width:100%;height:100%;object-fit:contain;">`;
    } else {
        const faviconUrl = `https://icons.duckduckgo.com/ip3/${new URL(site.url).hostname}.ico`;
        const img = document.createElement('img');
        img.src = faviconUrl;
        img.style.width = '100%';
        img.style.height = '100%';
        img.style.objectFit = 'contain';
        img.onerror = function() {
            iconDiv.textContent = site.name.charAt(0).toUpperCase();
            iconDiv.style.backgroundColor = 'transparent';
        };
        img.onload = function() {
            iconDiv.innerHTML = '';
            iconDiv.appendChild(img);
        };
        iconDiv.textContent = site.name.charAt(0).toUpperCase();
        iconDiv.style.backgroundColor = 'transparent';
        iconDiv.appendChild(img);
    }

    const nameSpan = document.createElement('span');
    nameSpan.className = 'fav-name';
    nameSpan.textContent = site.name;

    shortcut.appendChild(iconDiv);
    shortcut.appendChild(nameSpan);

    shortcut.onclick = () => window.open(site.url, '_blank');

    // Silme butonu
    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete-btn';
    deleteButton.textContent = '×';
    deleteButton.style.display = 'block';
    deleteButton.onclick = function(e) {
        e.stopPropagation();
        shortcut.remove();
        removeOutsideFav(idx);
    };
    shortcut.appendChild(deleteButton);

    // Dışarıdaki kısayolu sürükleyerek yer değiştirme
    let offsetX = 0, offsetY = 0, isDragging = false;
    shortcut.addEventListener('dragstart', function(e) {
        isDragging = true;
        offsetX = e.clientX - shortcut.getBoundingClientRect().left;
        offsetY = e.clientY - shortcut.getBoundingClientRect().top;
    });
    shortcut.addEventListener('dragend', function(e) {
        if (!isDragging) return;
        isDragging = false;
        const winRect = document.querySelector('.window').getBoundingClientRect();
        if (
            e.clientX > winRect.left &&
            e.clientX < winRect.right &&
            e.clientY > winRect.top &&
            e.clientY < winRect.bottom
        ) {
            let outsideFavs = JSON.parse(localStorage.getItem('outsideFavs')) || [];
            let fav = outsideFavs[idx];
            outsideFavs.splice(idx, 1);
            localStorage.setItem('outsideFavs', JSON.stringify(outsideFavs));
            let favs = JSON.parse(localStorage.getItem('myRetroFavs')) || [];
            // ICON: custom icon bilgisini koru
            favs.push({ name: fav.name, url: fav.url });
            localStorage.setItem('myRetroFavs', JSON.stringify(favs));
            loadFavorites();
        } else {
            const maxLeft = window.innerWidth - GRID_SIZE;
            const maxTop = window.innerHeight - GRID_SIZE;
            const snappedLeft = snapToGrid(e.clientX - offsetX, maxLeft);
            const snappedTop = snapToGrid(e.clientY - offsetY, maxTop);
            shortcut.style.left = snappedLeft + 'px';
            shortcut.style.top = snappedTop + 'px';
            updateOutsideFavPosition(idx, snappedLeft, snappedTop);
        }
    });

    // Sağ tıklama ile ikon değiştirme (dışarıda da çalışsın)
    shortcut.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = 'image/*';
        fileInput.style.display = 'none';
        document.body.appendChild(fileInput);
        fileInput.onchange = function(ev) {
            const file = ev.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = function(event) {
                customIcons[site.url] = event.target.result;
                localStorage.setItem('customFavIcons', JSON.stringify(customIcons));
                loadFavorites();
                renderOutsideFavs();
            };
            reader.readAsDataURL(file);
        };
        fileInput.click();
        setTimeout(() => fileInput.remove(), 1000);
    });

    document.body.appendChild(shortcut);
}

function updateOutsideFavPosition(idx, x, y) {
    const GRID_SIZE = 80;
    function snapToGrid(coord, max) {
        let snapped = Math.round(coord / GRID_SIZE) * GRID_SIZE;
        if (snapped < 0) snapped = 0;
        if (snapped > max) snapped = max;
        return snapped;
    }
    const maxLeft = window.innerWidth - GRID_SIZE;
    const maxTop = window.innerHeight - GRID_SIZE;
    let outsideFavs = JSON.parse(localStorage.getItem('outsideFavs')) || [];
    if (outsideFavs[idx]) {
        outsideFavs[idx].x = snapToGrid(x, maxLeft);
        outsideFavs[idx].y = snapToGrid(y, maxTop);
        localStorage.setItem('outsideFavs', JSON.stringify(outsideFavs));
    }
}

// Dışarıdaki favorileri localStorage'da tut
function saveOutsideFav(site, x, y) {
    let outsideFavs = JSON.parse(localStorage.getItem('outsideFavs')) || [];
    outsideFavs.push({ ...site, x, y });
    localStorage.setItem('outsideFavs', JSON.stringify(outsideFavs));
}

function removeOutsideFav(idx) {
    let outsideFavs = JSON.parse(localStorage.getItem('outsideFavs')) || [];
    outsideFavs.splice(idx, 1);
    localStorage.setItem('outsideFavs', JSON.stringify(outsideFavs));
    renderOutsideFavs();
}

function renderOutsideFavs() {
    // Önce var olanları temizle
    document.querySelectorAll('.outside-fav').forEach(e => e.remove());
    let outsideFavs = JSON.parse(localStorage.getItem('outsideFavs')) || [];
    outsideFavs.forEach((site, idx) => {
        createOutsideShortcut(site, site.x, site.y, idx);
    });
}

// Grid içindeki fav-item'lara pencere dışına sürükleme desteği ekle
function enableOutsideDrag() {
    const favItems = document.querySelectorAll('.fav-item');
    favItems.forEach(item => {
        item.addEventListener('dragend', function(e) {
            const winRect = document.querySelector('.window').getBoundingClientRect();
            if (
                e.clientX < winRect.left ||
                e.clientX > winRect.right ||
                e.clientY < winRect.top ||
                e.clientY > winRect.bottom
            ) {
                const idx = parseInt(item.dataset.index, 10);
                let favs = JSON.parse(localStorage.getItem('myRetroFavs'));
                if (favs && favs[idx]) {
                    // Dışarıya ekle ve grid'den sil
                    createOutsideShortcut(favs[idx], e.clientX, e.clientY, getOutsideFavsLength());
                    saveOutsideFav(favs[idx], e.clientX, e.clientY);
                    favs.splice(idx, 1);
                    localStorage.setItem('myRetroFavs', JSON.stringify(favs));
                    loadFavorites();
                }
            }
        });
    });
}

function getOutsideFavsLength() {
    let outsideFavs = JSON.parse(localStorage.getItem('outsideFavs')) || [];
    return outsideFavs.length;
}

window.deleteFavorite = deleteFavorite;
window.addFavorite = addFavorite;

