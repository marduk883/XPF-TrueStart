console.log("Service worker started.");
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "suggest") {
        fetch(`https://suggestqueries.google.com/complete/search?client=firefox&q=${msg.q}`)
            .then(res => res.json())
            .then(data => sendResponse(data))
            .catch(err => sendResponse({error: err.toString()}));
        return true;
    }
});
